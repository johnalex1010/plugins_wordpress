# AGENTS.md

Reglas locales para cualquier agente que trabaje en `spec-modal-checklist`.

Este archivo complementa el `AGENTS.md` raíz del repositorio. Si hay contradicción sobre archivos dentro de esta carpeta, gana esta regla local salvo que degrade seguridad, estabilidad o arquitectura global.

## Contexto del plugin

- Nombre: SPEC Modal Pro.
- Archivo principal: `spec-modal-checklist.php`.
- Text domain: `spec-modal-pro`.
- CPT privado: `smp_modal`.
- Versión documentada: 3.7.
- Requiere WordPress 6.0+ y PHP 7.4+.
- Render frontend: modal promocional segmentado por página y rol.

## Reglas específicas

- Mantener el prefijo `smp_` para funciones, metadatos y helpers propios.
- No cambiar el CPT `smp_modal` sin SPEC completa y plan de migración.
- No cambiar post meta existentes sin validar compatibilidad:
  - `_smp_enabled`
  - `_smp_delay`
  - `_smp_frequency`
  - `_smp_start_date`
  - `_smp_end_date`
  - `_smp_pages`
  - `_smp_cta_url`
  - `_smp_cta_target`
  - `_smp_cta_id`
  - `_smp_cta_label`
  - `_smp_image_id`
  - `_smp_media_type`
  - `_smp_video_id`
  - `_smp_video_poster_id`
  - `_smp_mobile_title`
  - `_smp_mobile_description`
  - `_smp_youtube_url`
- Mantener estado activo/inactivo por modal.
- Mantener segmentación por páginas y roles.
- Mantener frecuencia `session` o `persistent` de 1 hora salvo SPEC contraria.
- Mantener imagen obligatoria para publicar cuando el comportamiento documentado lo requiera.
- Mantener tipos de contenido con allowlist `image`, `video` (MP4/WebM) y `youtube`; los modales sin `_smp_media_type` se tratan como `image`.
- Con video o YouTube, el CTA se renderiza como botón debajo del video reutilizando URL, target e ID Tag Manager.
- Orden de carga del video: primero la imagen. La portada del MP4/WebM va en `data-smp-poster` y el JS la asigna como `poster` antes de pedir la metadata. YouTube muestra su miniatura y solo carga el iframe al hacer clic. No volver a poner `poster` ni `src` del iframe directo en el HTML.
- La proporción del modal de video (`--smp-video-ratio` y clase `smp-modal--portrait`/`--landscape`) se calcula en PHP con `smp_get_modal_video_dimensions()` para evitar el salto de 16:9 a vertical; no depender solo del evento `loadedmetadata`.
- Con video MP4/WebM, el video y la portada (`_smp_video_poster_id`) son obligatorios para publicar: si faltan, `wp_insert_post_data` pasa el modal a borrador. La portada debe ser una imagen de la biblioteca de medios y se renderiza como atributo `poster`. El render no exige la portada, para no ocultar modales ya publicados antes de esta regla.
- Con video MP4/WebM o YouTube, el título móvil y la descripción corta son obligatorios para publicar. Por debajo de 800px (breakpoint compartido entre `frontend.css` y `frontend.js`) el overlay con clase `smp-overlay--has-mobile` oculta el video y muestra ese texto con el mismo CTA; sin esa clase el modal no se muestra en móvil.
- Mantener target con allowlist `_self` y `_blank`.
- Mantener programación opcional por fecha de inicio y fecha de fin, con fechas vacías como comportamiento siempre vigente cuando el modal esté publicado y activo.
- Mantener estado administrativo dependiente de programación y pasar automáticamente a borrador cuando la fecha de fin esté vencida.

## Código limpio local

- Mantener funciones `smp_` pequeñas y separadas por responsabilidad: registro, metaboxes, guardado, segmentación, frecuencia, consulta y render.
- Usar nombres explícitos para variables de estado, delay, frecuencia, páginas, roles, CTA, imagen y target.
- Mantener la lógica de frecuencia y segmentación legible, con estados vacíos y errores esperables tratados de forma explícita.
- Evitar duplicar validaciones de roles, páginas, target, frecuencia o URLs si existe un helper claro.
- Mantener JS del modal encapsulado, sin variables globales innecesarias, listeners duplicados ni manipulación insegura del DOM.
- Mantener CSS del modal acotado al namespace del plugin para evitar conflictos con el tema.
- Si se modifica control de foco, cierre o persistencia, documentar impacto accesible y validación manual.

## Seguridad y accesibilidad

- Validar capacidades antes de guardar.
- Mantener nonces en metaboxes.
- Sanitizar IDs, URL, target, delay, frecuencia, roles y páginas.
- Escapar toda salida.
- Mantener `rel="noopener noreferrer"` para `_blank`.
- Mantener `role="dialog"` y `aria-modal="true"` en frontend.
- Mantener cierre accesible y control de foco cuando se modifique el modal.

## Traducciones

- Si cambia texto visible, revisar `languages/`.
- No editar manualmente `.mo`.
- Mantener UTF-8 y text domain `spec-modal-pro`.
- Validar español e inglés cuando cambie copy.
- Mantener fallback interno para locales `en*` si se modifica traducción PHP.

## Validación local

Después de cambios relevantes ejecutar, según aplique:

```bash
php -l spec-modal-checklist.php
node --check assets/js/admin.js
node --check assets/js/frontend.js
```

Validar manualmente en WordPress si cambia UI o render:

- creación y edición de modales
- selección de imagen
- URL y target de CTA
- asignación de páginas y roles
- jerarquía padre/hija en el selector de páginas
- columnas administrativas
- render frontend
- cierre y frecuencia
- responsive mobile, tablet y desktop
- ausencia de errores en consola

## Rollback local

Restaurar los archivos modificados dentro de `spec-modal-checklist/`, limpiar cachés si aplica y validar que el CPT `smp_modal` cargue en el administrador.
