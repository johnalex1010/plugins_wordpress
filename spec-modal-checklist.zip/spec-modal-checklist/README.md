# SPEC Modal Pro

Plugin WordPress para gestionar modales promocionales segmentados por página.

## Descripción

SPEC Modal Pro crea un Custom Post Type privado (`smp_modal`) para administrar modales con imagen clickeable, frecuencia y páginas asignadas. El plugin no crea URLs públicas propias y no modifica metadata SEO, canonicales, schema ni configuración de Yoast SEO.

## Funcionalidades

- CPT privado para modales.
- Estado activo/inactivo por modal.
- Segmentación por páginas con ruta jerárquica padre/hija en el selector.
- Delay configurable.
- Frecuencia `session` o `persistent` de 1 hora.
- Programación opcional con fecha de inicio y fecha de fin.
- Estado administrativo calculado por programación: sin fechas usa `Publicado` / `Borrador`; con fechas usa `Programado`, `Publicado` o `Borrador`.
- Cambio automático a borrador cuando la fecha de fin ya está vencida.
- URL y target para enlazar la imagen del modal.
- ID opcional para seguimiento en Tag Manager sobre el enlace de la imagen.
- Imagen obligatoria para publicar.
- Columnas administrativas de estado, activo y páginas asignadas.
- Tabla informativa de páginas donde hay modales activos.
- Assets separados para admin y frontend.
- Internacionalización mediante text domain `spec-modal-pro`, traducción inglesa `en_US` y fallback interno para locales `en*`.

## Capturas

Sube las imágenes de referencia en `docs/images/` usando estos nombres para que se muestren aquí automáticamente.

### Listado en administrador

![Listado de modales](docs/images/admin-list.png)

### Configuración del modal

![Configuración del modal](docs/images/admin-config.png)

### Vista en frontend

![Modal en frontend](docs/images/frontend.png)

## Seguridad

- Bloqueo de acceso directo con `ABSPATH`.
- Nonce en guardado de metabox.
- Validación de permisos con `current_user_can()`.
- Sanitización con `absint()`, `sanitize_key()`, `sanitize_html_class()`, `sanitize_text_field()` y `esc_url_raw()`.
- Allowlists para frecuencia, target y modo de imagen.
- Validación de páginas tipo `page`.
- Escape de salida con `esc_html()`, `esc_attr()`, `esc_url()` y `wp_kses_post()`.
- `rel="noopener noreferrer"` cuando el enlace abre en nueva pestaña.

## Código limpio y mantenibilidad

Este plugin debe mantenerse legible, modular y escalable:

- Funciones `smp_` pequeñas y enfocadas en una sola responsabilidad.
- Nombres descriptivos para estado, delay, frecuencia, páginas, roles, CTA, imagen y target.
- Lógica de segmentación, frecuencia y cierre expresada de forma clara y verificable.
- Validaciones explícitas para roles, páginas, frecuencia, target, URLs e IDs.
- JS encapsulado, sin variables globales innecesarias, listeners duplicados ni `console.log`.
- CSS del modal acotado al namespace del plugin para reducir conflictos visuales.
- Comentarios solo cuando expliquen decisiones de accesibilidad, compatibilidad o persistencia.

## SEO / GEO / AEO

- No genera CPT público ni URLs indexables propias.
- No duplica metadata, canonicales ni schema de Yoast.
- Usa HTML accesible para el modal con `role="dialog"` y `aria-modal="true"`.
- Las imágenes se renderizan mediante `wp_get_attachment_image()`.

## Estructura

```text
spec-modal-checklist/
  spec-modal-checklist.php
  README.md
  assets/
    css/
      admin.css
      frontend.css
    js/
      admin.js
      frontend.js
  languages/
    spec-modal-pro.pot
    spec-modal-pro-en_US.po
    spec-modal-pro-en_US.mo
    spec-modal-pro-en_US.l10n.php
  docs/
    images/
      admin-list.png
      admin-config.png
      frontend.png
```

## Validación recomendada

```bash
php -l spec-modal-checklist.php
node --check assets/js/admin.js
node --check assets/js/frontend.js
```

Validar traducciones:

- Cambiar el idioma de WordPress o del usuario administrador a English (United States).
- Confirmar que el CPT, metabox, columnas administrativas, frecuencia, selector de medios y botón de cierre muestran textos en inglés.
- Volver a Español y confirmar que los textos originales se mantienen.

Nota: el plugin incluye fallback interno para locales `en*`, por lo que los textos visibles del administrador y el botón de cierre del modal deben mostrarse en inglés incluso si WordPress no carga el archivo `.mo` o `.l10n.php`.

Validar en WordPress:

- Crear y editar modal.
- Seleccionar imagen.
- Guardar URL y target.
- Guardar ID Tag Manager y confirmar que se renderiza como `id` del enlace cuando existe URL.
- Asignar páginas.
- Confirmar que el selector muestra jerarquía de páginas cuando existen padres.
- Revisar columnas administrativas.
- Configurar fecha de inicio futura y fecha de fin vencida para confirmar que la vigencia controla el render.
- Confirmar que un modal publicado con fecha de fin vencida pasa automáticamente a borrador en el administrador.
- Verificar render frontend, cierre y frecuencia.

## Rollback

Restaurar `spec-modal-checklist.php`, los archivos en `assets/` y la carpeta `languages/`. No hay migraciones de base de datos; el plugin usa post meta estándar:

- `_smp_enabled`
- `_smp_delay`
- `_smp_frequency`
- `_smp_start_date`
- `_smp_end_date`
- `_smp_pages`
- `_smp_cta_url`
- `_smp_cta_id`
- `_smp_cta_target`
- `_smp_image_id`
